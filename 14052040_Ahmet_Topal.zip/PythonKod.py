#Görüntü İşleme 2.Ödevi
#Content Based Image Retrieval
import cv2
import numpy as np

#0->red
#1->green
#2->blue

#Bu fonksiyon LBP görüntüsüne ait histogram çıkarma işlevini gerçekleştirmektedir.
#Parameter olarak LBP görüntüsünü almaktadır.
#Geriye normalize edilmiş histogram değerlerini döndürmektedir.
def LBPImageHistogram(LBPImage):
    max_gray_level = 256;
    Hist_Image = np.zeros((max_gray_level,1))

    #LBP görüntüsü için histogram hesaplıyoruz.
    for i in range(0,LBPImage.shape[0]):
        for j in range(0, LBPImage.shape[1]):
            Hist_Image[np.int(LBPImage[i,j])]=Hist_Image[np.int(LBPImage[i,j])]+1
    
    #Görüntünün yükseklik ve genişlik uzunlarına bölerek histogram dizisini normalize ediyoruz.
    Hist_Image_Normalization = Hist_Image/(LBPImage.shape[0]*LBPImage.shape[1])
    
    return  Hist_Image_Normalization
    
# Bu fonksiyon Uniform LBP histogram hesaplama işlevini gerçekleştirmektedir.
# Parametre olarak LBP görüntüsünü almaktadır.
# Uniform Histogram dizisini geri döndürmektedir.
def UniformLBPHistogram(LBPImage):
    #En fazla 2 geçiş olan patternleri alıyoruz.
    pattern = patternsAtMostTwoTransition()#59 adet pattern geldi.
    #[0-256] değerlerinin npormalize frekansını ölçüyoruz.
    Histo = LBPImageHistogram(LBPImage)
    
    UniformLBPHistogram = []
    ratioSummation=0;
    for i in range(len(pattern)):
        #Her bir patternin LBP görüntüsündeki normalize edilmiş değerini Uniform LBP'ye ekliyoruz.
        dic = {"Pattern":pattern[i], "Ratio":Histo[pattern[i],0]}
        UniformLBPHistogram.append(dic);
        #Non-uniform patternlerin oran bilgisini bulmak için uniform olanların oran bilgisini topluyoruz.
        ratioSummation = ratioSummation + Histo[pattern[i],0]
    
    UniformLBPHistogram.append({"Pattern":"other", "Ratio":1-ratioSummation})
    
    return UniformLBPHistogram

# Bu fonksiyon bir görüntünün LBP'sini elde etmektedir.
def LBPImageGenerator(Image):
    
    height=Image.shape[0]
    width=Image.shape[1]
    
    LBP = np.zeros((height, width)) # Görüntü ile aynı boyutta bir LBP matrisi oluşturuldu.
    
    window = 3#8 bitlik bir sayı oluşturacağımzıdan 3x3 lük komşuluk alındı.
    
    center_pixel_w = np.int(window/2)
    center_pixel_h = np.int(window/2)
    
    i = center_pixel_h
    j = center_pixel_w
    
    
    while(i < height-np.int(window/2) and j < width- np.int(window/2)):
        
        i_temp = i+np.int(window/2)
        j_temp = j+np.int(window/2)
        power = 0#power ise 2 nin kaçıncı kuvvetini alacağımızı gösterecek.
        summation=0#summation ilgili hücrenin LBP değerini tutacak.
        
        while(i_temp>=i-np.int(window/2) and j_temp>=j-np.int(window/2)):
            #Eğer baktığımzı hücredeki eleman windowun ortadaki pikselinden büyük veya eşit ise
            #2'nin ilgili kuvvetini alma işlemi yapıyoruz. Ayrıca ortadaki pikseli atlıyoruz.
            if (i_temp!=i or j_temp!=j)  and Image[i_temp,j_temp]>=Image[i,j]:
                summation = summation + pow(2,power)
                power=power+1
            #Değilse ilgili hücre 0 olacağından herhangi bir katkı gelmeyecek sadece power artıyor.
            elif (i_temp!=i or j_temp!=j)  and Image[i_temp,j_temp]<Image[i,j]:
                power=power+1
            #Eğer window içerisinde sütunun sonuna gelindiyse bir sonraki satıra geçiyoruz. 
            if  j_temp == j - np.int(window/2):
                j_temp = j + np.int(window/2)
                i_temp = i_temp-1
            #Gelinmediyse bir sonraki sütundan devam ediyoruz.
            else:
                j_temp = j_temp-1
        
        LBP[i,j]=summation
        #Eğer görüntü içerisinde sütunun sonuna gelindiyse bir alt satırdan devam et.
        if j+np.int(window/2) == width-np.int(window/2):
            j = center_pixel_w
            i = i+1
        #Gelinmediyse bir sonraki sütundan devam et.
        else:
            j = j+1
    
    return LBP

#Bu fonksiyon Uniform LBP histogramını çıkarmak için maksimum en fazla geçiş olan patternleri bulur.
#Parametresi yoktur. Geriye en fazla 2 geçişe sahip olan patternleri döndürür.
def patternsAtMostTwoTransition():
    count=0
    pattern = []
    for i in range(0,256):
        temp = i
        j = 0
        
        transition = 0
        
        Dig = [] # Decimal sayıyı ikilik düzende tutacağımız Digit dizimiz.
        
        #Decimal bir sayıyı ikilik düzende yazıyoruz.
        while(j < 8):#binary sayımız 8 digitten oluşuyor.
            digit = temp%2;#2 ile kalanına bakıyoruz. Bu digiti diziye kaydeediyoruz.
            temp = np.int(temp/2)
            Dig.append(digit)
            j = j+1;
        
        Dig = Dig[::-1]
        #Geçişleri yakalamak için sırasıyla bir önceki ve bir sonraki elemanı kontrol ediyoruz.
        #Geçiş varsa ilgili counter bir artıyor.
        for k in range(len(Dig)-1):
            if Dig[k]!=Dig[k+1]:
                transition=transition+1
        
        #Eğer geçiş sayısı en fazla 2 ise diziye ekleme işlemini gerçekleştiriyoruz.
        if transition<=2:
            pattern.append(i)
            count = count+1
        
    return pattern

#Her bir test örneğinin en yakın olduğu 3 görüntüyü manhattan uzaklığına göre hesaplamaktadır.
#Parametre olarak test örneklerini, veri kümesindeki sınıfların isimlerini, train kümesindeki örneklerin
#LBP histogramlarını almaktadır. Geriye toplam doğru sayısı ile her bir sınıfa ait doğru sayısını döndürmektedir.
def testImageSetPerformance(test, classes, LBP_Histograms):
    True_Predict = 0
    True_Class = {'banded':0,'bubbly':0, 'chequered':0, 'cobwebbed':0, 'crystalline':0, 'dotted':0, 'honeycombed':0, 'striped':0, 'zigzagged':0 }
    
    for str_test in test:
        Manhattan_Distance = []
        All_Manhattan = []
        Image = cv2.imread(str_test+'.jpg')
        #Görüntüyü Griye YCbCr uzayoındaki Y bileşeninden çeviriyoruz.
        Image = ObtainLuminanceYComponent(Image)
        #Gri görüntünün LBP görüntüsünü hesaplıyoruz.
        LBPImage = LBPImageGenerator(Image)
        #LBPImage = np.uint8(LBPImage)
        #Uniform LBP hesaplıyoruz.
        TestLBPHistogram = UniformLBPHistogram(LBPImage)
        
        for img_train in range(len(LBP_Histograms)):
            #Sırasıyla train kümesindeki her bir örneğin histogramını parametre olarak gönderdiğimiz
            #diziden çekiyoruz.
            histo = LBP_Histograms[img_train]['Uniform_LBP_Histogram']
            distance = 0 # Manhattan distance değerini tutacak.
            for ind in range(len(histo)):
                #Test örneğinin histogramı ile traindeki ilgili örneğin histogramının karşılık gelen
                #elemanlarının mutlak değerlerini topluyoruz.
                distance = distance + np.abs(histo[ind]['Ratio']-TestLBPHistogram[ind]['Ratio'])
            
            #Bulduğumuz bu uzaklıkları kaydediyoruz. 
            All_Manhattan.append(distance)
            Manhattan_Distance.append({'Image':LBP_Histograms[img_train]['Image'], 'Distance':distance})
        
        mostSimilar=[]
        All_Manhattan = sorted(All_Manhattan)
       
        #Sorgu görüntüsüne en benzer 3 görüntüyü buluyoruz.
        for i in range(3):
            for j in range(len(Manhattan_Distance)):
                if Manhattan_Distance[j]['Distance']==All_Manhattan[i]:
                    mostSimilar.append(Manhattan_Distance[j]['Image'])
        
                    
        flag = 1 # En az bir tane kendi sınıfı ile aynı görüntüyü bulduysa yeterli olacağından fazla sayım yapmamak için tutuyopruz.
        # Burada 
        for i in range(len(classes)):
            if classes[i] in str_test:#sorgu örneğinin hangi sınıftan olduğuna bakıyoruz.
                for j in range(len(mostSimilar)):#En benzer üç resmin sorgu örneğinin sınıfıyla aynı olup olmadığını kıyaslıyoruz.
                    if classes[i] in mostSimilar[j] and flag==1:#Aynıysa ve daha önce bu bloğu çalıştırmadıysa True değeri bir artıyor.
                        True_Predict = True_Predict + 1
                        True_Class[classes[i]] = True_Class[classes[i]] + 1
                        flag=0
    
    
    
    return True_Predict, True_Class

#Yukarıdaki fonksiyonun tüm test örneklerini değerlendirme işlemini yapıyordu. Aşağıdaki fonksiyon
#parametre olarak gelen sorgu görüntüsünün en benzer olduğu görüntüyü bulup ekranda sorgu görüntüsüne
#olan mesafeleriyle görüntülemektedir. Parametre olarak sorgu görüntüsü ile Trainden çıkarılan LBP
# histogramlarını almaktadır. 
def evaluateOneTestExample(Image,LBP_Histograms):
    Manhattan_Distance = []
    All_Manhattan = []

    Imagey = ObtainLuminanceYComponent(Image)
        
    LBPImage = LBPImageGenerator(Imagey)
    #LBPImage = np.uint8(LBPImage)
    
    TestLBPHistogram = UniformLBPHistogram(LBPImage)
        
    for img_train in range(len(LBP_Histograms)):
        histo = LBP_Histograms[img_train]['Uniform_LBP_Histogram']
        distance = 0
        for ind in range(len(histo)):
            distance = distance + np.abs(histo[ind]['Ratio']-TestLBPHistogram[ind]['Ratio'])
            
        All_Manhattan.append(distance)
        Manhattan_Distance.append({'Image':LBP_Histograms[img_train]['Image'], 'Distance':distance})
        
    mostSimilar=[]
    All_Manhattan = sorted(All_Manhattan)
       
    for i in range(3):
        for j in range(len(Manhattan_Distance)):
            if Manhattan_Distance[j]['Distance']==All_Manhattan[i]:
                  mostSimilar.append(Manhattan_Distance[j]['Image'])
    
    cv2.imshow('First Most Similar-'+mostSimilar[0]+" Distance:"+str(All_Manhattan[0]),cv2.imread(mostSimilar[0]+'.jpg'))
    #cv2.imwrite("First_Similar_Image_zigzagged.jpg",cv2.imread(mostSimilar[0]+'.jpg'))
    cv2.imshow('Second Most Similar-'+mostSimilar[1]+" Distance:"+str(All_Manhattan[1]),cv2.imread(mostSimilar[1]+'.jpg'))
    #cv2.imwrite("Second_Similar_Image_zigzagged.jpg",cv2.imread(mostSimilar[1]+'.jpg'))
    cv2.imshow('Third Most Similar-'+mostSimilar[2]+" Distance:"+str(All_Manhattan[2]),cv2.imread(mostSimilar[2]+'.jpg'))
    #cv2.imwrite("Third_Similar_Image_zigzagged.jpg",cv2.imread(mostSimilar[2]+'.jpg'))
    cv2.imshow('Image',Image)
    cv2.waitKey()
    
    return Manhattan_Distance,mostSimilar

# Renkli görüntüyü gri görüntüye çevirmek için YCbCr renk uzayının Y bileşenini hesaplamaktadır.
#Parametre olarak renkli görüntüyü almaktadır. Geriye gri görüntüyü döndürmektedir.
def ObtainLuminanceYComponent(Image):
    
    h=Image.shape[0]
    w=Image.shape[1]
    
    Luminance=np.zeros((h,w))
    
    #Aişağıda her piksel için formülasyonu uygulayarak Y bileşeni elde ediliyor.
    for i in range(h):
        for j in range(w):
            Luminance[i,j] = 16+(65.481/255)*Image[i,j,0]+(128.553/255)*Image[i,j,1]+(24.966/255)*Image[i,j,2]
            
    return np.uint8(Luminance)
    
#Train veri kümesi içerisinde yer alan her bir görüntünün tek bir seferde Uniform LBP histogramlarını
#çıkarmaktadır. Parametre olarak tüm eğitim kümesini almaktadır. Geriye Uniform LBP histogramlarını
#döndürmektedir.
def trainandExtractLBPs(train):
    
    LBP_Histograms = []
    
    for i in range(len(train)): #Train kümesindeki her bir görüntü sınıfını almaktadır.
        for string in train[i]: #İlgili küme içerisindeki görüntüleri üzerinde tek tek hesaplama yapmaktadır.
            
            Image = cv2.imread(string+'.jpg')
            #Görüntüyü okuyup gri görüntüye dönüştürmektedir.
            Image = ObtainLuminanceYComponent(Image)
            
            #İlgili gri görüntünün LBP histogramlarını çıkarmaktadır.
            LBPImage = LBPImageGenerator(Image)

            path = string + '.jpg'
            #LBP görüntüsünden uniform LBP histogramını çıkartmaktadır. 
            Uniform_LBP_Hist = UniformLBPHistogram(LBPImage)
            #Bu histogramı ilgili diziye kaydetmektedir.
            LBP_Histograms.append({'Image':string, 'Uniform_LBP_Histogram':Uniform_LBP_Hist})
        print((i+1),".görsel kümesi tamamlandı.\n")
    
    return LBP_Histograms

def main():
    
    train_banded = ['banded_0002','banded_0004','banded_0005','banded_0006','banded_0008',
              'banded_0009','banded_0010','banded_0011','banded_0012','banded_0016','banded_0019',
              'banded_0021','banded_0023','banded_0024','banded_0039']
    train_bubbly = ['bubbly_0038','bubbly_0044','bubbly_0045','bubbly_0046','bubbly_0049','bubbly_0050',
              'bubbly_0052','bubbly_0053','bubbly_0055','bubbly_0056','bubbly_0060','bubbly_0061',
              'bubbly_0066','bubbly_0070']
    train_chequered = ['chequered_0017','chequered_0042','chequered_0043','chequered_0044','chequered_0045',
                 'chequered_0046','chequered_0048','chequered_0049','chequered_0050','chequered_0051',
                 'chequered_0052','chequered_0053','chequered_0054','chequered_0055','chequered_0062']
    train_cobwebbed =['cobwebbed_0030','cobwebbed_0040','cobwebbed_0041','cobwebbed_0044','cobwebbed_0046',
                'cobwebbed_0047','cobwebbed_0048','cobwebbed_0049','cobwebbed_0050','cobwebbed_0051',
                'cobwebbed_0052','cobwebbed_0053','cobwebbed_0055','cobwebbed_0058','cobwebbed_0059']
    train_crystalline = ['crystalline_0057','crystalline_0102','crystalline_0104','crystalline_0105','crystalline_0106',
                   'crystalline_0108','crystalline_0207','crystalline_0208','crystalline_0210','crystalline_0211',
                   'crystalline_0212','crystalline_0213','crystalline_0214','crystalline_0215','crystalline_0219']
    train_dotted = ['dotted_0101','dotted_0182','dotted_0183','dotted_0184','dotted_0185','dotted_0186','dotted_0187',
              'dotted_0188','dotted_0189','dotted_0190','dotted_0191','dotted_0192','dotted_0193','dotted_0194',
              'dotted_0196','dotted_0197','dotted_0198']
    train_honeycombed=['honeycombed_0049','honeycombed_0051','honeycombed_0052','honeycombed_0109','honeycombed_0110',
                 'honeycombed_0112','honeycombed_0114','honeycombed_0115','honeycombed_0116','honeycombed_0117',
                 'honeycombed_0118','honeycombed_0119','honeycombed_0120','honeycombed_0121','honeycombed_0122']
    train_striped = ['striped_0011','striped_0012','striped_0013','striped_0020','striped_0024','striped_0025',
               'striped_0071','striped_0073','striped_0078','striped_0079','striped_0094','striped_0096',
               'striped_0097','striped_0098','striped_0105']
    train_zigzagged = ['zigzagged_0010','zigzagged_0040','zigzagged_0042','zigzagged_0043','zigzagged_0044','zigzagged_0045',
                 'zigzagged_0046','zigzagged_0047','zigzagged_0048','zigzagged_0049','zigzagged_0050','zigzagged_0052',
                 'zigzagged_0053','zigzagged_0054','zigzagged_0056']
    
    
    train=[train_banded,train_bubbly,train_chequered,train_cobwebbed,train_crystalline,train_dotted,train_honeycombed,train_striped,train_zigzagged]
    
    LBP_Histograms = trainandExtractLBPs(train)
    
    ########################################## END OF TRAINING ############################################# 
    
    ########################################## TESTING STARTING ############################################
    test = ['banded_0013','banded_0030','banded_0033','bubbly_0073','bubbly_0075','bubbly_0120',
            'chequered_0100','chequered_0111','chequered_0176','cobwebbed_0120','cobwebbed_0122',
            'cobwebbed_0126','crystalline_0111','crystalline_0114','crystalline_0116','dotted_0062',
            'dotted_0072','dotted_0090','honeycombed_0003','honeycombed_0045','honeycombed_0150',
            'striped_0076','striped_0100','striped_0122','zigzagged_0008','zigzagged_0009',
            'zigzagged_0014']
    
    
    classes = ["banded","bubbly","chequered","cobwebbed","crystalline","dotted","honeycombed","striped","zigzagged"]
    
    True_Predict_Total, True_Per_Class = testImageSetPerformance(test, classes, LBP_Histograms)
    
    print("Model Performance: %",100*True_Predict_Total/len(test))
  
    ########################################## OTHER IMAGES TO BE WANTED TO ATTACHED TO THE REPORT ############################################# 
    Attached = ['banded_0025','bubbly_0089','chequered_0084','cobwebbed_0121','crystalline_0112','dotted_0196',
                'honeycombed_0100','striped_0002','zigzagged_0015']
    
    Image = cv2.imread('banded_0025.jpg')
    a,b=evaluateOneTestExample(Image,LBP_Histograms)
    
    

    
    
if __name__ == "__main__":
    main()